# iNBIO Next.js App

1) `npm i`
2) `cp .env.local.example .env.local` then set `NEXT_PUBLIC_GAS_ENDPOINT`
3) `npm run dev`
