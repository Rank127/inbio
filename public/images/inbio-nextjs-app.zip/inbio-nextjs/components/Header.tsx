"use client";
export default function Header(){
  return (
    <header className='w-full border-b border-slate-200 bg-white/80 backdrop-blur supports-[backdrop-filter]:bg-white/60 sticky top-0 z-50'>
      <div className='mx-auto container-tight px-4'>
        <div className='flex items-center justify-between h-16'>
          <a href='#top' className='flex items-center gap-3 group' aria-label='iNBIO home'>
            <span className='w-9 h-9 rounded-xl bg-emerald-500 grid place-content-center text-white font-black'>i</span>
            <span className='font-semibold group-hover:text-emerald-600'>International BioRefineries</span>
          </a>
          <nav className='hidden md:flex items-center gap-7 text-sm'>
            <a href='#solutions' className='hover:text-emerald-700'>Solutions</a>
            <a href='#technology' className='hover:text-emerald-700'>Technology</a>
            <a href='#industries' className='hover:text-emerald-700'>Industries</a>
            <a href='#impact' className='hover:text-emerald-700'>Impact</a>
            <a href='#resources' className='hover:text-emerald-700'>Resources</a>
            <a href='#contact' className='hover:text-emerald-700'>Contact</a>
          </nav>
          <div className='flex items-center gap-3'>
            <a href='#contact' className='hidden sm:inline-block px-4 py-2 rounded-xl bg-emerald-600 text-white font-medium hover:bg-emerald-700'>Get a Quote</a>
            <button aria-label='Open menu' className='md:hidden p-2 rounded-lg hover:bg-slate-100' onClick={()=>{const m=document.getElementById('mnav'); if(m) m.classList.toggle('hidden');}}>
              <svg width='24' height='24' fill='none' stroke='currentColor' strokeWidth='2' viewBox='0 0 24 24' aria-hidden='true'><path d='M4 6h16M4 12h16M4 18h16'/></svg>
            </button>
          </div>
        </div>
        <div id='mnav' className='md:hidden hidden pb-4'>
          <div className='grid gap-2 text-sm'>
            <a href='#solutions' className='py-2'>Solutions</a>
            <a href='#technology' className='py-2'>Technology</a>
            <a href='#industries' className='py-2'>Industries</a>
            <a href='#impact' className='py-2'>Impact</a>
            <a href='#resources' className='py-2'>Resources</a>
            <a href='#contact' className='py-2'>Contact</a>
          </div>
        </div>
      </div>
    </header>
  );
}