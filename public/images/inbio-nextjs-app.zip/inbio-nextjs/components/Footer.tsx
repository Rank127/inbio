export default function Footer(){
  return (
    <footer className='py-10 bg-slate-950 text-slate-300'>
      <div className='mx-auto container-tight px-4 flex flex-col md:flex-row items-center justify-between gap-4'>
        <p className='text-sm'>© <span id='y'>{new Date().getFullYear()}</span> International BioRefineries · All rights reserved.</p>
        <nav className='text-sm flex gap-4'>
          <a href='#resources' className='hover:text-white'>Resources</a>
          <a href='#faq' className='hover:text-white'>FAQ</a>
          <a href='#contact' className='hover:text-white'>Contact</a>
          <a href='#top' className='hover:text-white'>Back to top ↑</a>
        </nav>
      </div>
    </footer>
  );
}