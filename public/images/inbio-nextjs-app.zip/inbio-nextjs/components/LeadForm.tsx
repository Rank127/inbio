"use client";
import { useState } from 'react';
export default function LeadForm(){
  const [status,setStatus]=useState('');
  const endpoint=process.env.NEXT_PUBLIC_GAS_ENDPOINT||'';
  const supportEmail=process.env.NEXT_PUBLIC_SUPPORT_EMAIL||'info@inbio.net';
  async function onSubmit(e:any){
    e.preventDefault();
    if(!endpoint){ setStatus(`Form endpoint not configured. Please email ${supportEmail}.`); return; }
    const form=e.currentTarget;
    const formData=new FormData(form);
    const data:any={}; formData.forEach((v,k)=>data[k]=String(v));
    setStatus('Sending…');
    try{
      const res=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
      const json=await res.json();
      if(json.ok){ setStatus('Thanks! Your message is in our Gmail inbox.'); form.reset(); }
      else { setStatus(`Something went wrong. Please email ${supportEmail}.`); }
    }catch{ setStatus(`Network error. Please email ${supportEmail}.`); }
  }
  return (
    <form id='lead-form' className='bg-white/10 backdrop-blur p-6 rounded-2xl border border-white/10' onSubmit={onSubmit}>
      <div className='grid gap-4'>
        <label className='text-sm'>Name<input required className='mt-1 w-full p-3 rounded-xl text-slate-900' name='name' placeholder='Your full name' /></label>
        <label className='text-sm'>Email<input required type='email' className='mt-1 w-full p-3 rounded-xl text-slate-900' name='email' placeholder='name@company.com' /></label>
        <label className='text-sm'>Company<input className='mt-1 w-full p-3 rounded-xl text-slate-900' name='company' placeholder='Organization' /></label>
        <label className='text-sm'>What are you interested in?
          <select name='interest' className='mt-1 w-full p-3 rounded-xl text-slate-900'>
            <option>Turnkey Plant</option>
            <option>Biochar</option>
            <option>Bio‑Oil / Biofuels</option>
            <option>Partnership</option>
          </select>
        </label>
        <label className='text-sm'>Feedstock & Volume<textarea className='mt-1 w-full p-3 rounded-xl text-slate-900' name='feedstock' rows={3} placeholder='Type, moisture, daily tons…'></textarea></label>
        <label className='text-sm'>Message<textarea className='mt-1 w-full p-3 rounded-xl text-slate-900' name='message' rows={4} placeholder='Project goals, timeline, location…'></textarea></label>
        <input type='hidden' name='source' value='inbio.net contact' />
        <button className='mt-2 px-5 py-3 rounded-xl bg-emerald-500 font-semibold hover:bg-emerald-600'>Send</button>
        <p className='text-xs text-slate-300'>This form posts to your Gmail via Google Apps Script.</p>
        <p id='status' className='text-sm'>{status}</p>
      </div>
    </form>
  );
}