import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "International BioRefineries (iNBIO) | Biomass-to-Energy Plants, Biochar & Biofuels",
  description: "International BioRefineries (iNBIO) designs and supplies fast‑pyrolysis biomass‑to‑energy plants and markets high‑performance biochar and bio‑oil/biofuels for agriculture, infrastructure and industry.",
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en"><body className="bg-white text-slate-900 antialiased tracking-tight">{children}</body></html>);
}