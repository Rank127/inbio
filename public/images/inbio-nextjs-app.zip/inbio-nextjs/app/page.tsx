import Header from '@/components/Header';
import Footer from '@/components/Footer';
import LeadForm from '@/components/LeadForm';

export default function HomePage(){
  return (
    <>
      <Header />
      <main>
        <section id='top' className='radial relative overflow-hidden'>
          <div className='mx-auto container-tight px-4 py-20 md:py-28'>
            <div className='grid md:grid-cols-2 gap-12 items-center'>
              <div>
                <h1 className='text-4xl md:text-5xl font-extrabold leading-tight'>
                  Convert Waste Biomass into <span className='text-emerald-600'>Biofuels</span>, <span className='text-emerald-600'>Biochar</span> & <span className='text-emerald-600'>Clean Energy</span>
                </h1>
                <p className='mt-4 text-slate-700 text-lg'>iNBIO designs and supplies modular <strong>fast‑pyrolysis</strong> plants and premium bio‑based products that reduce disposal costs, cut emissions, and create new revenue streams.</p>
                <div className='mt-6 flex gap-3 flex-wrap'>
                  <a href='#contact' className='px-5 py-3 rounded-xl bg-emerald-600 text-white font-semibold hover:bg-emerald-700'>Request Proposal</a>
                  <a href='#technology' className='px-5 py-3 rounded-xl bg-slate-900 text-white font-semibold hover:bg-slate-800'>How It Works</a>
                </div>
                <p className='mt-4 text-xs text-slate-500'>Serving agriculture, municipalities, forestry, food processing, and industrial clients.</p>
              </div>
              <figure className='relative'>
                <img loading='lazy' src='https://images.unsplash.com/photo-1542601098-8fc114e148e8?q=80&w=1200&auto=format&fit=crop' alt='Biomass processing plant at sunset' className='w-full rounded-2xl shadow-2xl' />
                <figcaption className='sr-only'>Modular biomass‑to‑energy plant</figcaption>
              </figure>
            </div>
            <div className='mt-10 grid sm:grid-cols-3 gap-4'>
              <div className='p-4 rounded-xl border bg-white/80'>
                <p className='text-2xl font-extrabold'>6–200 TPD</p>
                <p className='text-sm text-slate-600'>Scalable plant capacity</p>
              </div>
              <div className='p-4 rounded-xl border bg-white/80'>
                <p className='text-2xl font-extrabold'>&gt;70% Carbon</p>
                <p className='text-sm text-slate-600'>High‑quality biochar</p>
              </div>
              <div className='p-4 rounded-xl border bg-white/80'>
                <p className='text-2xl font-extrabold'>Multi‑Feedstock</p>
                <p className='text-sm text-slate-600'>Wood waste, ag residues, poultry litter</p>
              </div>
            </div>
          </div>
        </section>

        <section id='solutions' className='py-20 bg-slate-50'>
          <div className='mx-auto container-tight px-4'>
            <div className='max-w-2xl'>
              <h2 className='text-3xl md:text-4xl font-extrabold'>Solutions</h2>
              <p className='mt-2 text-slate-700'>Choose a turnkey plant, buy biochar and bio‑oil fuels, or partner with iNBIO to convert your waste streams into value.</p>
            </div>
            <div className='mt-10 grid md:grid-cols-3 gap-6'>
              <article className='rounded-2xl border bg-white p-6 shadow-sm'>
                <h3 className='text-xl font-bold'>Turnkey Biomass‑to‑Energy Plants</h3>
                <p className='mt-2 text-sm text-slate-700'>Modular fast‑pyrolysis systems with feed prep, reactor, condensation train, biochar handling, and controls. Options for CHP, emissions control, and remote monitoring.</p>
                <ul className='mt-3 text-sm list-disc pl-5 space-y-1 text-slate-700'>
                  <li>6–200 TPD modules, expand on demand</li>
                  <li>Handles wood chips, ag residues, poultry litter</li>
                  <li>Outputs: biochar, bio‑oil, process gas for heat/power</li>
                </ul>
                <a href='#contact' className='mt-4 inline-block text-emerald-700 font-semibold'>Get plant specs →</a>
              </article>
              <article className='rounded-2xl border bg-white p-6 shadow-sm'>
                <h3 className='text-xl font-bold'>iNBIO Biochar</h3>
                <p className='mt-2 text-sm text-slate-700'>High‑surface‑area biochar for soil health, water filtration, anaerobic digestion enhancement, and low‑embodied‑carbon concrete/asphalt mixes.</p>
                <ul className='mt-3 text-sm list-disc pl-5 space-y-1 text-slate-700'>
                  <li>Custom sizing & activation options</li>
                  <li>Agronomic & materials application guidance</li>
                  <li>Eligible for carbon‑removal credits (where applicable)</li>
                </ul>
                <a href='#contact' className='mt-4 inline-block text-emerald-700 font-semibold'>Request pricing →</a>
              </article>
              <article className='rounded-2xl border bg-white p-6 shadow-sm'>
                <h3 className='text-xl font-bold'>Bio‑Oil & Biofuels</h3>
                <p className='mt-2 text-sm text-slate-700'>Renewable bio‑oil for industrial heat, asphalt binder modification, and upgrading to drop‑in fuels. Explore pathways toward SAF and renewable diesel with partners.</p>
                <ul className='mt-3 text-sm list-disc pl-5 space-y-1 text-slate-700'>
                  <li>On‑spec supply and offtake options</li>
                  <li>Fuel credit & incentive advisory</li>
                  <li>Quality control & logistics support</li>
                </ul>
                <a href='#contact' className='mt-4 inline-block text-emerald-700 font-semibold'>Discuss offtake →</a>
              </article>
            </div>
          </div>
        </section>

        <section id='technology' className='py-20'>
          <div className='mx-auto container-tight px-4'>
            <div className='grid md:grid-cols-2 gap-10 items-start'>
              <div>
                <h2 className='text-3xl md:text-4xl font-extrabold'>Fast‑Pyrolysis, Simplified</h2>
                <p className='mt-3 text-slate-700'>In an oxygen‑free reactor, pre‑conditioned biomass is rapidly heated to volatilize organics. Vapors are condensed to liquid <em>bio‑oil</em>, solids become <em>biochar</em>, and a small fraction is <em>process gas</em> used to power the system.</p>
                <ol className='mt-4 list-decimal pl-6 space-y-2 text-slate-700'>
                  <li><strong>Feed Prep:</strong> drying, sizing, and metals removal.</li>
                  <li><strong>Reactor:</strong> precise residence time & temperature control.</li>
                  <li><strong>Condensation:</strong> multi‑stage quench produces stable bio‑oil.</li>
                  <li><strong>Finishing:</strong> biochar cooling, sizing, and packaging.</li>
                </ol>
                <div className='mt-6 grid sm:grid-cols-2 gap-3 text-sm'>
                  <div className='p-4 border rounded-xl'><span className='font-bold'>Controls:</span> PLC/SCADA, remote monitoring</div>
                  <div className='p-4 border rounded-xl'><span className='font-bold'>Emissions:</span> cyclones, thermal oxidizer options</div>
                  <div className='p-4 border rounded-xl'><span className='font-bold'>Safety:</span> interlocks, ATEX options</div>
                  <div className='p-4 border rounded-xl'><span className='font-bold'>Modularity:</span> staged capacity growth</div>
                </div>
              </div>
              <figure>
                <img loading='lazy' src='https://images.unsplash.com/photo-1599979675866-6eb2f9d6fca2?q=80&w=1200&auto=format&fit=crop' alt='Illustration of a modular pyrolysis line' className='w-full rounded-2xl shadow-2xl' />
              </figure>
            </div>
          </div>
        </section>

        <section id='industries' className='py-20 bg-slate-50'>
          <div className='mx-auto container-tight px-4'>
            <h2 className='text-3xl md:text-4xl font-extrabold'>Industries We Serve</h2>
            <div className='mt-8 grid sm:grid-cols-2 md:grid-cols-3 gap-6'>
              <div className='p-6 border rounded-2xl bg-white'>
                <h3 className='font-bold'>Agriculture & Poultry</h3>
                <p className='text-sm text-slate-700 mt-2'>Convert manures and litter into stable carbon, reduce nutrient runoff, and create local fuel.</p>
              </div>
              <div className='p-6 border rounded-2xl bg-white'>
                <h3 className='font-bold'>Forestry & Wood Waste</h3>
                <p className='text-sm text-slate-700 mt-2'>Valorize thinnings, sawdust, bark and storm debris into biochar and bio‑oil.</p>
              </div>
              <div className='p-6 border rounded-2xl bg-white'>
                <h3 className='font-bold'>Municipal & Utilities</h3>
                <p className='text-sm text-slate-700 mt-2'>Divert organics from landfill, cut methane, and produce renewable heat and materials.</p>
              </div>
              <div className='p-6 border rounded-2xl bg-white'>
                <h3 className='font-bold'>Asphalt & Construction</h3>
                <p className='text-sm text-slate-700 mt-2'>Improve binder performance with bio‑oil and embed biochar for low‑carbon mixes.</p>
              </div>
              <div className='p-6 border rounded-2xl bg-white'>
                <h3 className='font-bold'>Food & Beverage</h3>
                <p className='text-sm text-slate-700 mt-2'>Treat organic residues on‑site and recover energy/value.</p>
              </div>
              <div className='p-6 border rounded-2xl bg-white'>
                <h3 className='font-bold'>C&D & Land Management</h3>
                <p className='text-sm text-slate-700 mt-2'>Utilize brush/green waste while generating local jobs and fuels.</p>
              </div>
            </div>
          </div>
        </section>

        <section id='impact' className='py-20'>
          <div className='mx-auto container-tight px-4'>
            <div className='grid md:grid-cols-2 gap-10 items-center'>
              <div>
                <h2 className='text-3xl md:text-4xl font-extrabold'>Measurable Impact</h2>
                <p className='mt-3 text-slate-700'>Deploying an iNBIO system reduces disposal costs and emissions while creating new revenue from carbon‑rich products and credits (where eligible).</p>
                <ul className='mt-4 space-y-2 text-slate-700'>
                  <li>• Landfill diversion and methane reduction</li>
                  <li>• Carbon storage via durable biochar</li>
                  <li>• Renewable heat and fuel substitution</li>
                  <li>• Local jobs and resilient supply chains</li>
                </ul>
              </div>
              <div className='grid grid-cols-2 gap-4'>
                <div className='p-6 border rounded-2xl text-center'>
                  <p className='text-4xl font-black'>85–95%</p>
                  <p className='text-xs text-slate-600 mt-1'>typical volatile solids conversion</p>
                </div>
                <div className='p-6 border rounded-2xl text-center'>
                  <p className='text-4xl font-black'>40–65%</p>
                  <p className='text-xs text-slate-600 mt-1'>bio‑oil yield (feedstock dependent)</p>
                </div>
                <div className='p-6 border rounded-2xl text-center'>
                  <p className='text-4xl font-black'>25–35%</p>
                  <p className='text-xs text-slate-600 mt-1'>biochar yield (feedstock dependent)</p>
                </div>
                <div className='p-6 border rounded-2xl text-center'>
                  <p className='text-4xl font-black'>6–200</p>
                  <p className='text-xs text-slate-600 mt-1'>TPD modular capacity</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id='resources' className='py-20 bg-slate-50'>
          <div className='mx-auto container-tight px-4'>
            <h2 className='text-3xl md:text-4xl font-extrabold'>Resources</h2>
            <div className='mt-8 grid md:grid-cols-3 gap-6'>
              <article className='rounded-2xl border bg-white p-6'>
                <h3 className='font-bold'>Guide: Selecting Feedstocks for Fast‑Pyrolysis</h3>
                <p className='text-sm text-slate-700 mt-2'>Moisture, ash, and particle size drive yields and economics. Learn how to qualify material streams.</p>
                <a href='#contact' className='mt-3 inline-block text-emerald-700 font-semibold'>Download →</a>
              </article>
              <article className='rounded-2xl border bg-white p-6'>
                <h3 className='font-bold'>Biochar Applications & Carbon Credits</h3>
                <p className='text-sm text-slate-700 mt-2'>Use cases across agriculture, stormwater, and materials—and how projects may qualify for credits.</p>
                <a href='#contact' className='mt-3 inline-block text-emerald-700 font-semibold'>Learn more →</a>
              </article>
              <article className='rounded-2xl border bg-white p-6'>
                <h3 className='font-bold'>Pathways to Drop‑in Biofuels & SAF</h3>
                <p className='text-sm text-slate-700 mt-2'>Upgrading bio‑oil via hydroprocessing, co‑processing, and refinery partnerships.</p>
                <a href='#contact' className='mt-3 inline-block text-emerald-700 font-semibold'>Read article →</a>
              </article>
            </div>
          </div>
        </section>

        <section id='faq' className='py-20'>
          <div className='mx-auto container-tight px-4'>
            <h2 className='text-3xl md:text-4xl font-extrabold'>Frequently Asked Questions</h2>
            <div className='mt-8 grid md:grid-cols-2 gap-6'>
              <details className='rounded-2xl border p-6 bg-white'><summary className='font-semibold cursor-pointer'>What feedstocks can iNBIO systems process?</summary><p className='mt-3 text-slate-700'>Wood residues (chips, sawdust, bark), agricultural residues (corn stover, nut shells), and conditioned manures such as poultry litter. We help test and qualify your material.</p></details>
              <details className='rounded-2xl border p-6 bg-white'><summary className='font-semibold cursor-pointer'>What are the typical outputs?</summary><p className='mt-3 text-slate-700'>Biochar (solid carbon), bio‑oil (liquid fuel/chemical), and a small fraction of process gas used for system heat/power.</p></details>
              <details className='rounded-2xl border p-6 bg-white'><summary className='font-semibold cursor-pointer'>Do you sell biochar and bio‑oil?</summary><p className='mt-3 text-slate-700'>Yes—bulk and packaged biochar, plus bio‑oil supply and offtake partnerships subject to specs and logistics.</p></details>
              <details className='rounded-2xl border p-6 bg-white'><summary className='font-semibold cursor-pointer'>Can projects earn credits or incentives?</summary><p className='mt-3 text-slate-700'>Many regions offer incentives for low‑carbon fuels and durable carbon removal. We can help evaluate eligibility based on location and end‑use.</p></details>
            </div>
          </div>
        </section>

        <section id='contact' className='py-20 bg-slate-900 text-white'>
          <div className='mx-auto container-tight px-4'>
            <div className='grid md:grid-cols-2 gap-10 items-start'>
              <div>
                <h2 className='text-3xl md:text-4xl font-extrabold'>Request a Proposal</h2>
                <p className='mt-3 text-slate-300'>Tell us about your feedstocks, volumes, and goals. We’ll scope a plant or product supply to fit.</p>
                <div className='mt-6 text-sm text-slate-300'>
                  <p><strong>International BioRefineries, LLC</strong></p>
                  <p>31901 Tri‑County Way, Ste 102B, Salisbury, MD 21804</p>
                  <p>+1 (443) 739‑6077 · <a href='mailto:info@inbio.net' className='underline'>info@inbio.net</a></p>
                </div>
              </div>
              <LeadForm />
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}